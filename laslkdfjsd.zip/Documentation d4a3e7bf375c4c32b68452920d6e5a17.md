# Documentation

# Stepps to use it:

(Works only in linux)

---

## 1) Install `wmctrl` with the next lines:

- The program need it
- just copy and paste this to do it:

```jsx
sudo apt-get update
sudo apt-get install wmctrl
```

## 2) clone the repo or dowload the file:

- Just clone the repo with this comands:

```bash
git clone git@github.com:carBoggio/Close-All-Windows-in-linux.git
```

`or`

```bash
git clone https://github.com/carBoggio/Close-All-Windows-in-linux.git
```

`or download:`

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled.png)

## 3) Go to the folder **`Close-All-Windows-in-linux` That you download or clone**

- open in the console:

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%201.png)

## 4) Give to `closeWindows.sh` execute permissions

```bash
chmod +x closeWindows.sh
```

## 5) For execute the program:

just write in terminal in **`Close-All-Windows-in-linux` folder:**

- and it will execute

```bash
./closeWindows.sh
```

## 6) To make a easy execution:

<aside>
💡 You can make that the program execute with a shortcut, by press a key
Thats how you can do it:

</aside>

1. Just  go to `settings` and serch for `keyboard`:

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%202.png)

1. At the end of the `page` go to `view and Customize Shortcuts`
    
    ![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%203.png)
    

1. At the end go to `Custom Shortcuts`

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%204.png)

1. Add 1 shortcut:

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%205.png)

1. Copy the direction to **`Close-All-Windows-in-linux` folder**

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%206.png)

1. In the input that says `command` put:
    
    ![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%207.png)
    
    ```bash
    sh -c "<path-to-the-file>/closeWindows.sh"
    #Exp:
    sh -c "~/proyects/closeAllWindows/closeWindows.sh"
    ```
    
2. Then in the `Name` put the name put the name of your preference i put `closeAllWindows`
    - You can put what you want

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%208.png)

1. Then go to `Shortcut` and set the shortcut
    
    ![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%209.png)
    
    - Press <`ctrl or shirt or alt`> + <`Other letter` `or numeber`>
    - `Exp:` I use <`Ctrl`> + <`0`>
    
2. Onece you have all set it `close all` and `try to do it` 

![Untitled](Documentation%20d4a3e7bf375c4c32b68452920d6e5a17/Untitled%2010.png)